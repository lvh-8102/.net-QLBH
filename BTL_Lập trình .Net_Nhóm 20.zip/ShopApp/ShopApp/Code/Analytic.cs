﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopApp.Code
{
    public class Analytic
    {
        public int Day { get; set; }
        public double Money { get; set; }
    }
}
